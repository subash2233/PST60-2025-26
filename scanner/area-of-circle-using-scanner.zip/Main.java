import java.util.Scanner;

    public static void main(String[] args) {
        Scanner Scanner = new Scanner(System.in);

        System.out.print("Enter the radius of the circle: ");
        float radius = Scanner.nextFloat();

        
        float area = (float) (Math.PI * radius * radius);

      
        System.out.println("Area of the circle is: " + area);
    }

