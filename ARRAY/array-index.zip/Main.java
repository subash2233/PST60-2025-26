public class Main
{
	public static void main(String[] args) {
	    //int arr[]=new int[5];
	    int arr[]={1,2,3,4,5};
	    for(int i=0;i<=4;i++)
	    {
	    System.out.println(arr[i]);
	    }
	    }
}
