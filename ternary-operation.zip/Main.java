
public class Main
{
	public static void main(String[] args) {
	    int a=20;
	    int b=100;
	    boolean c=(a>b)?true:false; 
	    boolean d=(a<b)?true:false;
		System.out.println(c);
		System.out.println(d);
	}
}
