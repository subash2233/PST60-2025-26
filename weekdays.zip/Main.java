/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main
{
	public static void main(String[] args) {
	    int weekday=8;
	    switch(weekday){
	        case 1:
	            System.out.println("sunday");
	            break;
	            case 2:
	                System.out.println("monday");
	                break;
	                case 3:
	                    System.out.println("tuesday");
	                    break;
	                    case 4:
	                        System.out.println("wednesday");
	                        break;
	                        case 5:
	                            System.out.println("thursday");
	                            break;
	                            case 6:
	                                System.out.println("friday");
	                                break;
	                                case 7:
	                                    System.out.println("saturday");
	                                    break;
	                                    default:
	                                    System.out.println("undefined");
	    }
	    
	}
}
