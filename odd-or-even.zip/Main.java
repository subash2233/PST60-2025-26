public class Main
{
	public static void main(String[] args) {
	    int a=79;
	    if(a%2==0){
	        System.out.println("the number is odd");
	    }
	    else{
	        System.out.println("the number is even");
	    }
	}
    
}