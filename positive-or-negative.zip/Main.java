/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/

public class Main
{
	public static void main(String[] args) {
		int a=10;
		if (a>=0){
		    System.out.println("the number is positive");
		}
		else{
		    System.out.println("the number is negative");
	}
	}
}