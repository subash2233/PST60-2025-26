/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public static  void main (String []args) {
    int num1=10;
    int num2=20;
  int sum=num1+num2;
  int sub=num1-num2;
   int mul=num1*num2;
    int div=num1/num2;
     int Pre=num1%num2;
  System.out.println(sum);
  System.out.prin
 tln(sub);
  System.out.println(mul);
  System.out.println(div);
  System.out.println(Pre);

}
